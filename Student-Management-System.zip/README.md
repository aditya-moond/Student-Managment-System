# Student Management System

A beginner-friendly desktop Student Management System using Python, Tkinter and SQLite.

## Features
- Add, view, update and delete student records
- Search by name, course or email
- Input validation
- Automatic SQLite database creation

## Tech Stack
Python | Tkinter | SQLite | SQL

## Run
```bash
python student_management.py
```

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

def db():
    conn = sqlite3.connect("students.db")
    conn.execute("""CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, age INTEGER NOT NULL,
        course TEXT NOT NULL, email TEXT NOT NULL)""")
    conn.commit()
    return conn

def clear():
    for e in (name, age, course, email):
        e.delete(0, tk.END)

def show(rows=None):
    for x in table.get_children(): table.delete(x)
    conn = db()
    rows = rows if rows is not None else conn.execute("SELECT * FROM students").fetchall()
    conn.close()
    for r in rows: table.insert("", tk.END, values=r)

def add():
    try:
        values = (name.get().strip(), int(age.get()), course.get().strip(), email.get().strip())
        if not all(values[0::1]): raise ValueError
        conn = db()
        conn.execute("INSERT INTO students(name,age,course,email) VALUES(?,?,?,?)", values)
        conn.commit(); conn.close(); clear(); show()
    except ValueError:
        messagebox.showerror("Error", "Enter valid values in all fields.")

def selected_id():
    s = table.selection()
    return table.item(s[0])["values"][0] if s else None

def update():
    sid = selected_id()
    if sid is None: return messagebox.showwarning("Select", "Select a student first.")
    try:
        values = (name.get().strip(), int(age.get()), course.get().strip(), email.get().strip(), sid)
        conn = db()
        conn.execute("UPDATE students SET name=?,age=?,course=?,email=? WHERE id=?", values)
        conn.commit(); conn.close(); clear(); show()
    except ValueError:
        messagebox.showerror("Error", "Age must be a number.")

def delete():
    sid = selected_id()
    if sid is None: return messagebox.showwarning("Select", "Select a student first.")
    conn = db(); conn.execute("DELETE FROM students WHERE id=?", (sid,))
    conn.commit(); conn.close(); show()

def search():
    q = search_box.get().strip()
    conn = db()
    rows = conn.execute("""SELECT * FROM students
        WHERE name LIKE ? OR course LIKE ? OR email LIKE ?""",
        (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
    conn.close(); show(rows)

def select(event):
    s = table.selection()
    if not s: return
    v = table.item(s[0])["values"]; clear()
    for e, val in zip((name, age, course, email), v[1:]): e.insert(0, val)

root = tk.Tk()
root.title("Student Management System")
root.geometry("850x550")
tk.Label(root, text="Student Management System", font=("Arial", 22, "bold")).pack(pady=15)

frame = tk.Frame(root); frame.pack()
labels = ["Name", "Age", "Course", "Email"]; entries = []
for i, label in enumerate(labels):
    tk.Label(frame, text=label).grid(row=i, column=0, padx=10, pady=5)
    e = tk.Entry(frame, width=30); e.grid(row=i, column=1, padx=10, pady=5); entries.append(e)
name, age, course, email = entries

buttons = tk.Frame(root); buttons.pack(pady=10)
tk.Button(buttons, text="Add Student", width=15, command=add).grid(row=0,column=0,padx=5)
tk.Button(buttons, text="Update Student", width=15, command=update).grid(row=0,column=1,padx=5)
tk.Button(buttons, text="Delete Student", width=15, command=delete).grid(row=0,column=2,padx=5)
tk.Button(buttons, text="Clear", width=15, command=clear).grid(row=0,column=3,padx=5)

sf = tk.Frame(root); sf.pack(pady=5)
tk.Label(sf, text="Search:").grid(row=0,column=0,padx=5)
search_box = tk.Entry(sf, width=30); search_box.grid(row=0,column=1,padx=5)
tk.Button(sf, text="Search", command=search).grid(row=0,column=2,padx=5)
tk.Button(sf, text="Show All", command=lambda: show()).grid(row=0,column=3,padx=5)

table = ttk.Treeview(root, columns=("ID","Name","Age","Course","Email"), show="headings", height=10)
for c in ("ID","Name","Age","Course","Email"):
    table.heading(c, text=c)
table.column("ID", width=50); table.column("Name", width=170); table.column("Age", width=70)
table.column("Course", width=180); table.column("Email", width=250)
table.pack(pady=10); table.bind("<ButtonRelease-1>", select)

db().close()
show()
root.mainloop()
